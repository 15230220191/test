//
//  main.m
//  施工日记
//
//  Created by ASW on 2017-3-31.
//  Copyright © 2017年 ASW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
